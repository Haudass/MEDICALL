# -*- encoding: utf-8 -*-
{

	'name' : 'Medical',  
	'version' : '1.0',
	'author' : 'Thymbra',
	'category' : 'Generic Modules/Others',
	'depends' : ['base','sale','account','product'],
	'description' : """

About Medical
-------------
Medical is a multi-user, highly scalable, centralized Electronic Medical Record (EMR) and Hospital Information System for openERP.

Medical provides a free universal Health and Hospital Information System, so doctors and institutions all over the world, specially in developing countries will benefit from a centralized, high quality, secure and scalable system.


Medical at a glance:


    * Strong focus in family medicine and Primary Health Care

    * Major interest in Socio-economics (housing conditions, substance abuse, education...)

    * Diseases and Medical procedures standards (ICD-10 / ICD-10-PCS)

    * Patient Genetic and Hereditary risks : Over 4200 genes related to diseases (NCBI / Genecards)

    * Epidemiological and other statistical reports

    * 100% paperless patient examination and history taking

    * Patient Administration (creation, evaluations / consultations, history ... )

    * Doctor Administration

    * Lab Administration

    * Medicine / Drugs information (vademécum)

    * Medical stock and supply chain management

    * Hospital Financial Administration

    * Designed with industry standards in mind

    * Open Source : Licensed under GPL v3



Most of the action should occur at sourceforge, so check the main page http://sourceforge.net/projects/medical for the latest news and developer releases. 

""",
	"website" : "http://medical.sourceforge.net",
	"init_xml" : [],
	"demo_xml" : ["demo/medical_demo.xml"],
# Use the following line for English
	"update_xml" : ["medical_view.xml","data/appointment.xml","data/disease_categories.xml","data/diseases.xml","data/ethnic_groups.xml","data/occupations.xml","data/icd_10_pcs_2009_part1.xml","data/icd_10_pcs_2009_part2.xml","data/icd_10_pcs_2009_part3.xml","data/genetic_risks.xml","data/dose_units.xml"],
# Use the following line for spanish and comment the prior line.
#	"update_xml" : ["medical_view.xml","data/appointment.xml","data/disease_categories_es.xml","data/diseases_es.xml","data/ethnic_groups.xml","data/occupations.xml","data/icd_10_pcs_2009_part1.xml","data/icd_10_pcs_2009_part2.xml","data/icd_10_pcs_2009_part3.xml","data/genetic_risks.xml","data/dose_units.xml"],
#	"update_xml" : ["medical_view.xml"],
	"active": False 
}
