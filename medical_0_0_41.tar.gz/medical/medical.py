# coding=utf-8

#    Copyright (C) 2008-2009  Luis Falcon

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.



from mx import DateTime
from osv import fields, osv

class insurance (osv.osv):
	_name = "medical.insurance"
	_columns = {
		'name' : fields.char ('Number', size=64),
		'partner_id' : fields.many2one ('res.partner','Owner'),
		'company' : fields.many2one ('res.partner','Insurance Company'),
		'member_since' : fields.date ('Member since'),
		'member_exp' : fields.date ('Expiration date'),
		'category' : fields.char ('Category', size=64, help="Insurance company plan / category"),
		'type' : fields.selection([
                                ('state','State'),
                                ('labor_union','Labor Union / Syndical'),
                                ('private','Private'),

                                ], 'Insurance Type', select=True),

		'notes' : fields.text ('Extra Info'),

		}
insurance ()



class partner_patient (osv.osv):
	_name = "res.partner"
	_inherit = "res.partner"
	_columns = {
		'date' : fields.date('Partner since',help="Date of activation of the partner or patient"),
		'alias' : fields.char('alias', size=64),
		'ref': fields.char('ID Number', size=64, required=True),
                'is_patient' : fields.boolean('Patient', help="Check if the partner is a patient"),
                'is_doctor' : fields.boolean('Doctor', help="Check if the partner is a doctor"),
		'is_institution' : fields.boolean ('Institution', help="Check if the partner is a Medical Center"),
		'lastname' : fields.char('Last Name', size=128, help="Last Name"),
		'insurance' : fields.one2many ('medical.insurance','partner_id',"Insurance"),	
	}
        _sql_constraints = [
                ('ref_uniq', 'unique (ref)', 'The partner or patient code must be unique')
 		]

partner_patient ()

class product_medical (osv.osv):
	_name = "product.product"
	_inherit = "product.product"
	_columns = {
                'is_medicament' : fields.boolean('Medicament', help="Check if the product is a medicament"),
                'is_vaccine' : fields.boolean('Vaccine', help="Check if the product is a vaccine"),

	}
product_medical ()


#Add the partner relationship field to the contacts.
class partner_patient_address (osv.osv):
	_name = "res.partner.address"
	_inherit = "res.partner.address"
	_columns = {
		'relationship' : fields.char('relationship', size=64),
		'relative_id' : fields.many2one('res.partner','Patient', domain=[('is_patient', '=', True)], help="Patient ID"),
	}
partner_patient_address ()

class procedure_code (osv.osv):
	_description = "Medical Procedure"
	_name = "medical.procedure"
	_columns = {
		'name': fields.char ('ICD-10-PCS Code', size=16),
		'description' : fields.char ('ICD-10-PCS Long Text', size=256),
		}

	def name_search(self, cr, uid, name, args=[], operator='ilike', context={}, limit=80):
        	args2 = args[:]
        	if name:
            		args += [('name', operator, name)]
            		args2 += [('description', operator, name)]
        	ids = self.search(cr, uid, args, limit=limit)
        	ids += self.search(cr, uid, args2, limit=limit)
        	res = self.name_get(cr, uid, ids, context)
        	return res

procedure_code ()



class pathology_category(osv.osv):
        def name_get(self, cr, uid, ids, context={}):
                if not len(ids):
                        return []
                reads = self.read(cr, uid, ids, ['name','parent_id'], context)
                res = []
                for record in reads:
                        name = record['name']
                        if record['parent_id']:
                                name = record['parent_id'][1]+' / '+name
                        res.append((record['id'], name))
                return res

        def _name_get_fnc(self, cr, uid, ids, prop, foo, faa):
                res = self.name_get(cr, uid, ids)
                return dict(res)
        def _check_recursion(self, cr, uid, ids):
                level = 100
                while len(ids):
                        cr.execute('select distinct parent_id from medical_pathology_category where id in ('+','.join(map(str,ids))+')')
                        ids = filter(None, map(lambda x:x[0], cr.fetchall()))
                        if not level:
                                return False
                        level -= 1
                return True

        _description='Pathology Categories'
        _name = 'medical.pathology.category'
        _columns = {
                'name': fields.char('Category Name', required=True, size=128),
                'parent_id': fields.many2one('medical.pathology.category', 'Parent Category', select=True),
                'complete_name': fields.function(_name_get_fnc, method=True, type="char", string='Name'),
                'child_ids': fields.one2many('medical.pathology.category', 'parent_id', 'Childs Category'),
                'active' : fields.boolean('Active'),
        }
        _constraints = [
                (_check_recursion, 'Error ! You can not create recursive categories.', ['parent_id'])
        ]
        _defaults = {
                'active' : lambda *a: 1,
        }
        _order = 'parent_id,id'

pathology_category()


class pathology (osv.osv):
	_name = "medical.pathology"
	_description = "Pathologies"
	_columns = {
		'name' : fields.char ('Name', size=128, help="Pathology / disease name"),
		'code' : fields.char ('ICD-10 Code', size=5, help="WHO - International Classification of Diseases Code"),
		'category' : fields.many2one('medical.pathology.category','Pathology Category'),
		'chromosome' : fields.char ('Affected Chromosome', size=128, help="chromosome number"),
		'protein' : fields.char ('Protein involved', size=128, help="Name of the protein(s) affected"),
		'gene' : fields.char ('Gene', size=128, help="Name of the gene(s) affected"),
		'info' : fields.text ('Extra Info'),
	}

        _sql_constraints = [
                ('code_uniq', 'unique (code)', 'The pathology code must be unique')]


	def name_search(self, cr, uid, name, args=[], operator='ilike', context={}, limit=80):
        	args2 = args[:]
        	if name:
            		args += [('name', operator, name)]
            		args2 += [('code', operator, name)]
        	ids = self.search(cr, uid, args, limit=limit)
        	ids += self.search(cr, uid, args2, limit=limit)
        	res = self.name_get(cr, uid, ids, context)
        	return res

pathology ()


class medicament (osv.osv):

	def name_get(self, cr, uid, ids, context={}):
		if not len(ids):
			return []
		rec_name = 'name'
		res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
		return res

	_name = "medical.medicament"
	_columns = {
		'name' : fields.many2one ('product.product','Name', domain=[('is_medicament', '=', "1")],help="Commercial Name"),
		'active_component' : fields.char ('active component', size=128, help="Active Component"),
		'therapeutic_action' : fields.char ('Therapeutic effect', size=128, help="Therapeutic action"),
		'composition' : fields.text ('Composition',help="Components"),
		'indications' : fields.text ('Indication',help="Indications"),
		'dosage' : fields.text ('Dosage Instructions',help="Dosage / Indications"),
		'overdosage' : fields.text ('Overdosage',help="Overdosage"),
		'pregnancy_warning' : fields.boolean ('Pregnancy Warning', help="Check when the drug can not be taken during pregnancy or lactancy"),
		'pregnancy' : fields.text ('Pregnancy and Lactancy',help="Warnings for Pregnant Women"),
		'presentation' : fields.text ('Presentation',help="Packaging"),
		'adverse_reaction' : fields.text ('Adverse Reactions'),
		'storage' : fields.text ('Storage Conditions'),
		'notes' : fields.text ('Extra Info'),
		}

medicament ()


class vaccination (osv.osv):
	_name = "medical.vaccination"
	_columns = {
		'name' : fields.many2one ('product.product','Name', domain=[('is_vaccine', '=', "1")], help="Vaccine Name"),
		'date' : fields.datetime ('Date'),
		'dose' : fields.integer ('Dose Number'),
		'observations' : fields.char ('Observations', size=128),
		}
	_defaults = {
                'dose': lambda *a: 1
		}

vaccination ()

class drugs_recreational (osv.osv):
	_name="medical.drugs_recreational"
	_columns = {
		'name': fields.char ('Name', size=128, help="Name of the drug"),
		'street_name': fields.char ('Street names', size=256, help="Common name of the drug in street jargon"),
		'toxicity' : fields.selection([
                                ('0','None'),
                                ('1','Low'),
                                ('2','High'),
                                ('3','Extreme'),
                                ], 'Toxicity', select=True),		
		'addiction_level' : fields.selection([
                                ('0','None'),
                                ('1','Low'),
                                ('2','High'),
                                ('3','Extreme'),
                                ], 'Addiction Level', select=True),		
		'legal_status' : fields.selection([
                                ('0','Legal'),
                                ('1','Illegal'),
                                ], 'Legal Status', select=True),

		'info' : fields.text ('Extra Info'),
		}

drugs_recreational ()

class operational_area (osv.osv):
	_name = "medical.operational_area"
	_columns = {
		'name' :fields.char ('Name', size=128, help="Operational Area of the city or region"),
		'info' :fields.text ('Extra Information'),
		}

        _sql_constraints = [
                ('code_uniq', 'unique (name)', 'The Operational Area code name must be unique')]

operational_area ()

class operational_sector (osv.osv):
	_name = "medical.operational_sector"
	_columns = {
		'name' :fields.char ('Name', size=128, help="Region included in an operational area"),
		'operational_area' :fields.many2one ('medical.operational_area','Operational Area'),
		'info' :fields.text ('Extra Information'),
		}

        _sql_constraints = [
                ('code_uniq', 'unique (name,operational_area)', 'The Operational Sector code and OP Area combination must be unique')]

operational_sector ()

class family_code (osv.osv):
	_name = "medical.family_code"
	_columns = {
		'name' :fields.char ('Name', size=128, help="Family code within an operational sector"),
		'operational_sector' :fields.many2one ('medical.operational_sector','Operational Sector'),
		'members_ids' : fields.many2many ('res.partner', 'family_members_rel','family_id','members_id', 'Members'),
		'info' :fields.text ('Extra Information'),
		}

        _sql_constraints = [
                ('code_uniq', 'unique (name)', 'The Family code name must be unique')]

family_code ()

class specialty (osv.osv):
	_name = "medical.specialty"
	_columns = {
		'name' :fields.char ('Description', size=128, help="ie, Addiction Psychiatry"),
		'code' : fields.char ('Code', size=128, help="ie, ADP"),
	}
        _sql_constraints = [
                ('code_uniq', 'unique (name)', 'The Medical Specialty code must be unique')]

specialty ()


class physician (osv.osv):

	def name_get(self, cr, uid, ids, context={}):
		if not len(ids):
			return []
		rec_name = 'name'
		res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
		return res

	_name = "medical.physician"
	_description = "Information about the doctor"
	_columns = {
		'name' : fields.many2one ('res.partner','Doctor', domain=[('is_doctor', '=', "1")], help="Doctor Name"),
		'institution' : fields.many2one ('res.partner','Institution',domain=[('is_institution', '=', "1")],help="Instituion where she/he works"),
		'code' : fields.char ('ID', size=128, help="MD License ID"),
		'specialty' : fields.many2one ('medical.specialty','Specialty', help="Specialty Code"),
		'info' : fields.text ('Extra info'),
		}

physician ()


class appointment (osv.osv):
	_name = "medical.appointment"
	_columns = {
		'name' : fields.char ('ID',size=64, readonly=True, required=True),
		'patient' : fields.many2one ('res.partner','Patient', domain=[('is_patient', '=', "1")], help="Patient Name"),
		'appointment_date' : fields.datetime ('Date and Time'),
		'institution' : fields.many2one ('res.partner','Institution', domain=[('is_institution', '=', "1")],help="Medical Center"),
		'doctor' : fields.many2one ('res.partner','Doctor', domain=[('is_doctor', '=', "1")], help="Doctor Name"),
		'specialty' : fields.many2one ('medical.specialty','Specialty', help="Medical Specialty / Sector"),
		'urgency' : fields.selection([
				('a','Normal'),
				('b','Urgent'),
				('c','Medical Emergency'),
				], 'Urgency Level'),

		'comments' : fields.text ('Comments'),

		}
	_order = "appointment_date desc"

	_defaults = {
                'urgency': lambda *a: 'a',
	        'name': lambda self, cr, uid, context=None: \
		self.pool.get('ir.sequence').get(cr, uid, 'medical.appointment'),
        	}
	

	def name_get(self, cr, uid, ids, context={}):
		if not len(ids):
			return []
		res = []
		for r in self.read(cr, uid, ids, ['rec_name','appointment_date'],context):
			date = str(r['appointment_date'] or '')
			res.append((r['id'], date))
		return res


appointment ()


class test_type (osv.osv):
	_name = "medical.test"
	_description = "Type of Lab test"
	_columns = {
		'name' : fields.char ('Test',size=128,help="Test type, eg X-Ray, hemogram,biopsy..."),
		'code' : fields.char ('Code',size=128,help="Short name - code for the test"),
		'info' : fields.text ('Description'),
	}
        _sql_constraints = [
                ('code_uniq', 'unique (name)', 'The Lab Test code must be unique')]

test_type ()

class ethnic_group (osv.osv):
	_name ="medical.ethnicity"
	_columns = {
		'name' : fields.char ('Ethnic group',size=128),
		'code' : fields.char ('Code',size=64),
		}

ethnic_group ()

class occupation (osv.osv):
	_name = "medical.occupation"
	_description = "Ocuppation / Job"
	_columns = {
		'name' : fields.char ('Occupation', size=128),
		'code' : fields.char ('Code', size=64),
		}
occupation ()

class medical_dose (osv.osv):
	_name = "medical.dose.unit"
	_columns = {
		'name' : fields.char ('Unit',size=32),
		'desc' : fields.char ('Description',size=64),
		}

medical_dose ()


class patient_medication (osv.osv):

	_name = "medical.patient.medication"
	_columns = {
		'name' : fields.many2one ('medical.medicament','Medicament',help="Prescribed Medicament"),
		'prescription_id' : fields.char ('Prescription ID', size=64, help='Prescription ID. It is useful to group different medicaments in a single prescription'),
		'indication' : fields.many2one ('medical.pathology','Indication'),
		'dose' : fields.integer ('Dose'),
		'dose_unit' : fields.many2one ('medical.dose.unit','dose unit'),
		'route' : fields.selection ([
			('o','Oral'),
			('p','Enteral'),
			('m','Mucosal'),
			('p','Percutaneous'),
			('sc','Subcutaneous'),
			('iv','Intravenous'),
			('im','Intramuscular'),
			('ia','Intrarterial'),
			('ic','Intracardiac'),
			], 'Route', select=True),


		'frequency' : fields.integer ('Frecuency #'),
		'frequency_unit' : fields.selection ([
			('s','seconds'),
			('m','minutes'),
			('h','hours'),
			('d','days'),
			('w','weeks'),
			], 'unit', select=True),

		'review' : fields.datetime ('Review'),
		'quantity' : fields.integer ('Quantity'),
		'refills' : fields.integer ('Refills #'),
		'allow_substitution' : fields.boolean('Allow substituion'),  
		'start_treatment' : fields.datetime ('Start of treatment'),
		'end_treatment' : fields.datetime ('End of treatment'),
		'discontinued' :  fields.boolean('Discontinued'),
		'course_completed' : fields.boolean('Course Completed'),
		'doctor' : fields.many2one('medical.physician','Doctor', help="Doctor who prescribed the medicament"),
		'active' : fields.boolean('Active',help="Check this option if the patient is currently taking the medication"),
		'discontinued_reason' : fields.char ('Reason for discontinuation', size=128, help="Short description for discontinuing the treatment"),
		'adverse_reaction' : fields.text ('Adverse Reactions',help="Specific side effects or adverse reactions that the patient experienced"),
		'notes' : fields.text ('Extra Info'),
		}
	_defaults = {
                'frequency_unit': lambda *a: 'h',
                'quantity': lambda *a: 1
		}

	
patient_medication ()

class patient_disease_info (osv.osv):
	_name = "medical.patient.disease"
	_description = "Disease info"
	_columns = {
		'name' : fields.many2one ('medical.pathology','Medical Condition',required=True, help="Disease"),
		'doctor' : fields.many2one('medical.physician','Doctor', help="Doctor who treated or diagnosed the patient"),
		'diagnosed_date': fields.date ('Date of Diagnosis'),
		'age': fields.char ('Age when diagnosed',size=3,help='Patient age at the moment of the diagnosis. Can be estimative'),
		'pregnancy_warning': fields.boolean ('Pregnancy warning'),
		'weeks_of_pregnancy' : fields.integer ('Contracted in pregnancy week #'),
		'description' : fields.char ('Description', size=128),
		'is_on_treatment' : fields.boolean ('Currently on Treatment'),
		'pcs_code' : fields.many2one ('medical.procedure','ICD-10-PCS Code', help="ICD-10-PCS Code 7-character string"),
		'treatment_description' : fields.char ('Treatment Description',size=128),
		'date_start_treatment' : fields.date ('Start of treatment'),
		'date_stop_treatment' : fields.date ('End of treatment'),
		'status' : fields.selection ([
			('c','chronic'),
			('s','status quo'),
			('h','healed'),
			('i','improving'),
			('w','worsening'),
			], 'Status of the disease', select=True),
		'extra_info' : fields.text ('Extra Info'),
		}

patient_disease_info ()


class surgery (osv.osv):
	_name = "medical.surgery"
	_description = "Surgery"
	_columns = {
		'name' : fields.many2one ('medical.procedure','ICD-10-PCS Code', help="ICD-10-PCS Code 7-character string"),
		'pathology' : fields.many2one ('medical.pathology','Base condition', help="Base Condition / Reason"),
		'classification' : fields.selection ([
				('o','Optional'),
				('r','Required'),
				('u','Urgent'),
                                ], 'Surgery Classification', select=True),
		'surgeon' : fields.many2one('medical.physician','Surgeon', help="Surgeon who did the procedure"),
		'date': fields.datetime ('Date of the surgery'),
		'age': fields.char ('Patient age',size=3,help='Patient age at the moment of the surgery. Can be estimative'),
		'description' : fields.char ('Description', size=128),
		'extra_info' : fields.text ('Extra Info'),
		}

surgery ()


class perinatal_monitor (osv.osv):
	_name = "medical.perinatal.monitor"
	_description = "Perinatal monitor"
	_columns = {
		'name' : fields.char ('Internal code',size=128),
		'date' : fields.datetime ('Date and Time'),
		'systolic' : fields.integer ('Systolic Pressure'),
		'diastolic' : fields.integer ('Diastolic Pressure'),
		'contractions' : fields.integer ('Contractions'),
		'frequency' : fields.integer ('Mother\'s Heart Frequency'),
		'dilation' : fields.integer ('Cervix dilation'),
		'f_frequency' : fields.integer ('Fetus Heart Frequency'),
                'meconium' : fields.boolean('Meconium'),
		'bleeding' : fields.boolean ('Bleeding'),
		'fundal_height' : fields.integer ('Fundal Height'),
		'fetus_position' : fields.selection ([
			('n','Correct'),
			('o', 'Occiput / Cephalic Posterior'),
			('fb', 'Frank Breech'),
			('cb', 'Complete Breech'),
			('t', 'Transverse Lie'),
			('t', 'Footling Breech'),
			], 'Fetus Position', select=True),

		}

perinatal_monitor ()

class newborn (osv.osv):
	_name = "medical.newborn"
	_description = "newborn information"
	_columns = {
		'name' : fields.char ('Baby\'s name',size=128),
		'code' : fields.char ('Newborn ID', size=64,required=True),
                'birth_date' : fields.datetime('Date of Birth', required=True),
		'photo' : fields.binary ('Picture'),
		'sex' : fields.selection([
                                ('m','Male'),
                                ('f','Female'),
                                ], 'Sex', select=True, required=True),
		'cephalic_perimeter' : fields.integer ('Cephalic Perimeter'),
		'length' : fields.integer ('Length'),
		'weight' : fields.integer ('Weight'),
                'apgar1' : fields.integer('APGAR 1st minute'),
                'apgar5' : fields.integer('APGAR 5th minute'),
		'meconium': fields.boolean ('Meconium'),
		'congenital_diseases' : fields.many2many ('medical.patient.disease', 'newborn_disease_rel','patient_id','congenital_id', 'Congenital diseases'),
		'reanimation_stimulation' :fields.boolean ('Stimulation'),
		'reanimation_aspiration' :fields.boolean ('Aspiration'),
		'reanimation_intubation' :fields.boolean ('Intubation'),
		'reanimation_mask' :fields.boolean ('Mask'),
		'reanimation_oxygen' :fields.boolean ('Oxygen'),
		'test_vdrl' : fields.boolean ('VDRL'),
		'test_toxo' : fields.boolean ('Toxoplasmosis'),
		'test_chagas' : fields.boolean ('Chagas'),
		'test_billirubin' : fields.boolean ('Billirubin'),
		'test_audition' : fields.boolean ('Audition'),
		'test_metabolic' : fields.boolean ('The metabolic / genetic check ("heel stick") has been done', help="Fenilketonuria, Congenital Hypothyroidism, Quistic Fibrosis, Galactosemia"),
		'medication' : fields.many2many('medical.medicament', 'newborn_labor_rel','medicament_id','patient_id','Medicaments and anesthesics'),
		'responsible' : fields.many2one('medical.physician','Doctor in charge', help="Signed by the health professional"), 
		'dismissed' : fields.datetime('Dismissed from hospital'),
		'bd' : fields.boolean ('Born dead'),
		'died_at_delivery' : fields.boolean ('Died at delivery room'),
		'died_at_the_hospital' : fields.boolean ('Died at the hospital'),
		'died_being_transferred' : fields.boolean ('Died being transferred',help="The baby died being transferred to another health institution"),
		'tod' : fields.datetime('Time of Death'),
		'cod' : fields.many2one('medical.pathology', 'Cause of death'),
		'notes' : fields.text ('Notes'),
		
	}

        _sql_constraints = [
                ('code_uniq', 'unique (code)', 'The newborn ID must be unique')]


newborn ()





class puerperium_monitor (osv.osv):
	_name = "medical.puerperium.monitor"
	_description = "Puerperium Monitor"
	_columns = {
		'name' : fields.char ('Internal code',size=64),
		'date' : fields.datetime ('Date and Time', required=True),
		'systolic' : fields.integer ('Systolic Pressure'),
		'diastolic' : fields.integer ('Diastolic Pressure'),
		'frequency' : fields.integer ('Heart Frequency'),
		'lochia_amount' : fields.selection([
                                ('n','normal'),
                                ('e','abundant'),
                                ('h','hemorrhage'),
                                ], 'Lochia amount', select=True),

		'lochia_color' : fields.selection([
                                ('r','rubra'),
                                ('s','serosa'),
                                ('a','alba'),
                                ], 'Lochia color', select=True),

		'lochia_odor' : fields.selection([
                                ('n','normal'),
                                ('o','offensive'),
                                ], 'Lochia odor', select=True),

		'uterus_involution' : fields.integer ('Fundal Height', help="Distance between the symphysis pubis and the uterine fundus (S-FD) in cm"),
		'temperature' : fields.float ('Temperature'),
		}

puerperium_monitor ()



class perinatal (osv.osv):
	_name = "medical.perinatal"
	_description = "perinatal information"
	_columns = {
		'name' : fields.char ('code',size=128),
                'gravida_number' : fields.integer('Gravida #'),
                'abortion' : fields.boolean('Abortion'),
		'admission_date' : fields.datetime ('Admission date',help="Date when she was admitted to give birth"),
		'prenatal_evaluations' : fields.integer ('Prenatal evaluations',help="Number of visits to the doctor during pregnancy"),
		'start_labor_mode' : fields.selection ([
                                ('n','Normal'),
                                ('i','Induced'),
                                ('c','c-section'),
                                ], 'Labor mode', select=True),
		'gestational_weeks' : fields.integer ('Gestational weeks'),
		'gestational_days' : fields.integer ('Gestational days'),
		'fetus_presentation' : fields.selection ([
			('n','Correct'),
			('o', 'Occiput / Cephalic Posterior'),
			('fb', 'Frank Breech'),
			('cb', 'Complete Breech'),
			('t', 'Transverse Lie'),
			('t', 'Footling Breech'),
			], 'Fetus Presentation', select=True),
		'placenta_incomplete' : fields.boolean('Incomplete Placenta'),
		'placenta_retained' : fields.boolean('Retained Placenta'),
		'episiotomy' : fields.boolean('Episiotomy'),
		'vaginal_tearing' : fields.boolean('Vaginal tearing'),
                'forceps' : fields.boolean('Use of forceps'),
		'monitoring' : fields.many2many('medical.perinatal.monitor', 'patient_perinatal_monitor_rel','patient_id','monitor_ids','Monitors'),
		'newborn' : fields.many2many('medical.newborn', 'patient_newborn_rel','patient_id','newborn_ids','Newborn info'),
		'puerperium_monitor' : fields.many2many('medical.puerperium.monitor', 'patient_puerperium_monitor_rel','patient_id','puerperium_ids','Puerperium monitor'),
		'medication' : fields.many2many('medical.medicament', 'patient_labor_rel','medicament_id','patient_id','Medicaments and anesthesics'),
		'dismissed' : fields.datetime('Dismissed from hospital'),
		'died_at_delivery' : fields.boolean ('Died at delivery room'),
		'died_at_the_hospital' : fields.boolean ('Died at the hospital'),
		'died_being_transferred' : fields.boolean ('Died being transferred',help="The mother died being transferred to another health institution"),
		'notes' : fields.text ('Notes'),
	}

perinatal ()



class genetic_risk (osv.osv):
	_name= "medical.genetic.risk"
	_description= "Genetic Risks"
	_columns = {
		'name' : fields.char ('Official Symbol', size=16),
		'long_name' : fields.char ('Official Long Name', size=256),
		'gene_id' : fields.char ('Gene ID', size=8, help="default code from NCBI Entrez database."),
		'chromosome' : fields.char ('Affected Chromosome', size=2, help="Name of the affected chromosome"),
		'location' : fields.char ('Location', size=32, help="Locus of the chromosome"),
		'dominance' : fields.selection([
                                ('d','dominant'),
                                ('r','recessive'),
                                ], 'Dominance', select=True),		
		'info' : fields.text ('Information', size=128, help="Name of the protein(s) affected"),
	}


	def name_search(self, cr, uid, name, args=[], operator='ilike', context={}, limit=80):
        	args2 = args[:]
        	if name:
            		args += [('name', operator, name)]
            		args2 += [('long_name', operator, name)]
        	ids = self.search(cr, uid, args, limit=limit)
        	ids += self.search(cr, uid, args2, limit=limit)
        	res = self.name_get(cr, uid, ids, context)
        	return res

genetic_risk ()




class family_diseases (osv.osv):
	_name = "medical.family.diseases"
	_description = "Family Diseases"
	_columns = {
		'name' : fields.many2one ('medical.pathology', 'Disease'),
		'x_or_y' : fields.selection([
                                ('m','Maternal'),
                                ('f','Paternal'),
                                ], 'Maternal/Paternal', select=True),

		'relative' : fields.selection([
                                ('m','Mother'),
                                ('a','Father'),
                                ('b','Brother'),
                                ('s','Sister'),
                                ('au','Aunt'),
                                ('u','Uncle'),
                                ('ne','Nephew'),
                                ('ni','Niece'),
                                ('gf','Grandfather'),
                                ('gm','Grandmother'),
                                ('c','Cousin'),
                                ], 'Relative', help="First degree = sibblings, mother and father; second degree = Uncles, nephews and Nieces; third degree = Grandparents and cousins", select=True),


		}

family_diseases ()

	
class patient_data (osv.osv):
#	Automatically assign the family code
	def onchange_partnerid (self, cr, uid, ids, partner):
		family_code_id = ""
		if partner:
 			cr.execute ('select family_id from family_members_rel where members_id=%s limit 1',(partner,))
			try:
				family_code_id = str(cr.fetchone()[0])
			except:
				family_code_id = ""
			
		v = {'family_code':family_code_id}
		
		return {'value': v}	

	
		
	def _patient_age(self, cr, uid, ids, name, arg, context={}):
		def compute_age_from_dates (patient_dob):
			now=DateTime.now()
			if (patient_dob):
				dob=DateTime.strptime(patient_dob,'%Y-%m-%d')
				delta=DateTime.Age (now, dob)
				years_months_days = str(delta.years) +" "+ str(delta.months) +" "+" "+ str(delta.days)
			else:
				years_months_days = "No DoB !"
			
 
			return years_months_days
		result={}
	        for patient_data in self.browse(cr, uid, ids, context=context):
	            result[patient_data.id] = compute_age_from_dates (patient_data.dob)
	        return result

	_name = "medical.patient"
	_description = "Patient related information"
	_columns = {
                'name' : fields.many2one('res.partner','Patient', required="1", domain=[('is_patient', '=', True)], help="Patient ID"),
		'lastname' : fields.related ('name','lastname',type='char',string='Lastname'), 
		'family_code' : fields.many2one ('medical.family_code','Family',help="Family Code"),
		'identifier' : fields.related ('name','ref',type='char',string='ID'),
		'photo' : fields.binary ('Picture'),
		'dob' : fields.date ('Date of Birth'),
		'age' : fields.function(_patient_age, method=True, type='char', string='Patient Age'),
		'sex' : fields.selection([
                                ('m','Male'),
                                ('f','Female'),
                                ], 'Sex', select=True),
		'marital_status' : fields.selection([
                                ('s','Single'),
                                ('m','Married'),
				('w','Widowed'),
				('d','Divorced'),
				('x','Separated'),
                                ], 'Marital Status'),
		'blood_type' : fields.selection([
				('a','A'),
				('b','B'),
				('ab','AB'),
				('o','O'),
				], 'Blood Type'),
		'rh' : fields.selection([
				('+','+'),
				('-','-'),
				], 'Rh'),

# lifestyle section

		'excercise' : fields.boolean ('Excersise'),
		'excercise_minutes_day' : fields.integer ('Minutes / day'),
		'number_of_meals' : fields.integer ('Meals per day'),
		'eats_alone' : fields.boolean ('Eats alone',help="Check this box if the patient eats by him / herself."),
		'salt' : fields.boolean ('Salt',help="Check if patient consumes salt with the food"),
		'coffee' : fields.boolean ('Coffee'),
		'coffee_cups' : fields.integer ('Cups per day',help="Number of cup of coffee a day"),
		'soft_drinks' : fields.boolean ('Soft drinks (sugar)',help="Check if the patient consumes soft drinks with sugar"),
		'smoking' : fields.boolean ('Smokes'),
		'smoking_number' : fields.integer ('Cigarretes a day'),
		'ex_smoker' : fields.boolean ('Ex-smoker'),
		'second_hand_smoker' : fields.boolean ('Passive smoker', help="Check it the patient is a passive / second-hand smoker"),
		'age_start_smoking' : fields.integer ('Age started to smoke'),
		'alcohol' : fields.boolean ('Drinks Alcohol'),
		'alcohol_beer_number' : fields.integer ('Beer / day'),
		'alcohol_wine_number' : fields.integer ('Wine / day'),
		'alcohol_liquor_number' : fields.integer ('Liquor / day'),
		'drug_usage' : fields.boolean ('Drug Habits'),
		'drugs' : fields.many2many ('medical.drugs_recreational','patient_drugs_recreational_rel','patient_id','drugs_recreational_id','Drugs', help="Name of drugs that the patient consumes"),  
		'lifestyle_info' :fields.text ('Extra Information'),

# End of lifestyle section


# Socioeconomics

		'ses': fields.selection ([
			('0','Lower'),
			('1','Lower-middle'),
			('2','Middle'),
			('3','Middle-upper'),
			('4','Higher'),
			], 'Socioeconomics',help="SES - Socioeconomic Status"),


		'education': fields.selection ([
			('0','None'),
			('1','Incomplete Primary School'),
			('2','Primary School'),
			('3','Incomplete Secondary School'),
			('4','Secondary School'),
			('5','University'),
			], 'Education Level',help="Education Level"),


		'housing': fields.selection ([
			('0','Shanty, deficient sanitary conditions'),
			('1','Small, crowded but with good sanitary conditions'),
			('2','Comfortable and good sanitary conditions'),
			('3','Roomy and excellent sanitary conditions'),
			('4','Luxury and excellent sanitary conditions'),
			], 'Housing conditions',help="Housing and sanitary living conditions"),
		
		'hostile_area' : fields.boolean ('Hostile Area', help="Check this box if the patient lives in a zone of high hostility (eg, war)"),

		'sewers': fields.boolean ('Sanitary Sewers'),
		'water': fields.boolean ('Running Water'),
		'trash': fields.boolean ('Trash recolection'),
		'electricity': fields.boolean ('Electrical supply'),
		'gas': fields.boolean ('Gas supply'),
		'telephone': fields.boolean ('Telephone'),
		'television': fields.boolean ('Television'),
		'internet': fields.boolean ('Internet'),
		'single_parent': fields.boolean ('Single parent family'),
		'domestic_violence': fields.boolean ('Domestic violence'),
		'working_children': fields.boolean ('Working children'),
		'teenage_pregnancy': fields.boolean ('Teenage pregnancy'),
		'sexual_abuse': fields.boolean ('Sexual abuse'),
		'drug_addiction': fields.boolean ('Drug addiction'),
		'school_withdrawal': fields.boolean ('School withdrawal'),
		'prison_past': fields.boolean ('Has been in prison',),
		'prison_current': fields.boolean ('Is currently in prison'),
		'relative_in_prison': fields.boolean ('Relative in prison',help="Check if someone from the nuclear family - parents / sibblings  is or has been in prison"),

		'ses_notes' : fields.text ("Extra info"),

		'fam_apgar_help': fields.selection ([
			('0','None'),
			('1','Moderately'),
			('2','Very much'),
			], 'Help from family',help="Is the patient satisfied with the level of help coming from the family when there is a problem ?"),


		'fam_apgar_discussion': fields.selection ([
			('0','None'),
			('1','Moderately'),
			('2','Very much'),
			], 'Family discussions on problems',help="Is the patient satisfied with the level talking over the problems as family ?"),
		
		'fam_apgar_decisions': fields.selection ([
			('0','None'),
			('1','Moderately'),
			('2','Very much'),
			], 'Family decision making',help="Is the patient satisfied with the level of making important decisions as a group ?"),

		'fam_apgar_timesharing': fields.selection ([
			('0','None'),
			('1','Moderately'),
			('2','Very much'),
			], 'Family time sharing',help="Is the patient satisfied with the level of time that they spend together ?"),

		'fam_apgar_affection': fields.selection ([
			('0','None'),
			('1','Moderately'),
			('2','Very much'),
			], 'Family affection',help="Is the patient satisfied with the level of affection coming from the family ?"),


		'sexual_preferences' : fields.selection([
                                ('h','Heterosexual'),
                                ('g','Homosexual'),
				('b','Bisexual'),
				('t','Transexual'),
                                ], 'Sexual Preferences'),

		'sexual_practices' : fields.selection([
                                ('s','Safe / Protected sex'),
                                ('r','Risky / Unprotected sex'),
				], 'Sexual Practices'),

		'sexual_partners': fields.selection([
				('m','Monogamous'),
				('t','Poligamous'),
                                ], 'Sexual Partners'),

		'first_sexual_encounter': fields.integer ('Age first sexual encounter'),

		'anticonceptive': fields.selection ([
			('0','None'),
			('1','Pill / Minipill'),
			('2','Male condom'),
			('3','Vasectomy'),
			('4','Female sterilisation'),
			('5','Intra-uterine device'),
			('6','Withdrawal method'),
			('7','Fertility cycle awareness'),
			('8','Contraceptive injection'),
			('9','Skin Patch'),
			('10','Female condom'),
			], 'Anticonceptive Method'),

		'income' : fields.selection([
                                ('h','High'),
                                ('m','Medium / Average'),
				('l','Low'),
                                ], 'Income', select=True),


		'currently_pregnant' : fields.boolean ('Currently Pregnant'),
		'fertile' : fields.boolean ('Fertile', help="Check if patient is in fertile age"),
		'menarche' : fields.integer ('Menarche age'),
		'menopausal' : fields.boolean ('Menopausal'),
		'menopause' : fields.integer ('Menopause age'),
		'gravida' : fields.integer ('Gravida',help="Number of pregnancies"),
		'premature' : fields.integer ('Premature',help="Premature Deliveries"),
		'abortions' : fields.integer ('Abortions'),
		'full_term' : fields.integer ('Full Term', help="Full term pregnancies"),
		'gpa' :fields.char ('GPA',size=32,help="Gravida, Para, Abortus Notation. For example G4P3A1 : 4 Pregnancies, 3 viable and 1 abortion"),
		'born_alive' : fields.integer ('Born Alive'),
		'deaths_1st_week' : fields.integer ('Deceased during 1st week',help="Number of babies that die in the first week"),
		'deaths_2nd_week' : fields.integer ('Deceased after 2nd week',help="Number of babies that die after the second week"),
		'perinatal' : fields.many2many ('medical.perinatal', 'patient_perinatal_rel','patient_id','perinatal_id', 'Perinatal Info'),
		'occupation' : fields.many2one ('medical.occupation','Occupation'),
		'works_at_home' : fields.boolean ('Works at home',help="Check if the patient works at his / her house"),
		'hours_outside' : fields.integer ('Hours outside home',help="Number of hours a day the patient spend outside the house"),
		'ethnic_group' : fields.many2one ('medical.ethnicity','Ethnic group'),
		'allergy_info' : fields.text ('Allergy Info'),
		'allergies': fields.many2many ('medical.pathology','patient_medical_allergies_rel','patient_id','allergy_id',"Allergies"),
		'vaccinations': fields.many2many ('medical.vaccination','patient_medical_vaccination','patient_id','vaccination_id',"Vaccinations"),
		'medications' : fields.many2many('medical.patient.medication', 'patient_medication_rel','patient_id','medication_id','Medications'),
		'genetic_risks' : fields.many2many('medical.genetic.risk','patient_genetic_risks_rel','patient_id','genetic_risk_id','Genetic Risks'),
		'family_history' : fields.many2many ('medical.family.diseases', 'patient_familyhist_rel','patient_id','pathology_id', 'Family History'),
		'surgery' : fields.many2many ('medical.surgery', 'patient_surgery_rel','patient_id','surgery_id', 'Surgeries'),
		'disease' : fields.many2many ('medical.patient.disease', 'patient_disease_rel','patient_id','disease_id', 'Diseases'),
		'evaluation_ids' : fields.one2many ('medical.patient.evaluation','name','Evaluation'),
		'notes' : fields.text ('Notes'),
		'deceased' : fields.boolean ('Deceased',help="Mark if the patient has died"),
		'dod' : fields.datetime ('Date of Death'),
		'cod' : fields.many2one ('medical.pathology', 'Cause of Death'),

	}

        _sql_constraints = [
                ('name_uniq', 'unique (name)', 'The Patient already exists')]

patient_data ()



class patient_evaluation (osv.osv):

	_name = "medical.patient.evaluation"
	_description = "evaluation"
	_columns = {
		'name' : fields.many2one ('medical.patient','Patient ID', readonly=True),
                'evaluation_date' : fields.many2one ('medical.appointment','Evaluation Date'),
		'evaluation_endtime' : fields.datetime ('End of Evaluation'),
		'next_evaluation' : fields.many2one ('medical.appointment','Next evaluation'),
		'user_id' : fields.many2one ('res.users','Doctor', readonly=True),
		'derived_from' : fields.many2one('medical.physician','Derived from Doctor', help="Physician who escalated / derived the case"), 
		'derived_to' : fields.many2one('medical.physician','Derived to Doctor', help="Physician to whom escalate / derive the case"), 
		'evaluation_type' : fields.selection([
                                ('a','Ambulatory'),
                                ('e','Emergengy'),
                                ('i','Hospitalary'),
                                ('pa','Pre-arraganged appointment'),
                                ('pc','Periodic control'),
			        ('p','Phone call'),
                                ], 'Evaluation Type', select=True),
		'signs' : fields.text ('Signs'),
		'symptoms' : fields.text ('Symptoms'),
		'chief_complaint' : fields.char ('Chief Complaint', size=128,help='Chief Complaint'),
		'notes_complaint' : fields.text ('Complaint details'),
		'glycemia' : fields.float('Glycemia'),
		'cholesterol_total' : fields.float ('Cholesterol'),
		'hdl' : fields.integer ('HDL'),
		'ldl' : fields.integer ('LDL'),
		'tag' : fields.integer ('TAGs',help="Triacylglycerols (triglicerides) level"),
		'systolic' : fields.integer('Systolic Pressure'),
		'diastolic' : fields.integer('Diastolic Pressure'),
		'bpm' : fields.integer ('Heart Rate',help="Heart rated expressed in beats per minute"),
		'temperature' : fields.float('temperature (celsius)'),
		'weight' : fields.float('weight (kg)'),
		'height' : fields.float('height (cm)'),
		'bmi' : fields.float('Body Mass Index'),
		'abdominal_circ' : fields.float('Abdominal Circumference'),
		'loc' : fields.integer('Level of Consciousness', help="Level of Consciousness - on Glasgow Coma Scale :  1=coma - 15=normal"),
		'loc_eyes' : fields.integer('Level of Consciousness - Eyes', help="Eyes Response - Glasgow Coma Scale - 1 to 4"),
		'loc_verbal' : fields.integer('Level of Consciousness - Verbal', help="Eyes Response - Glasgow Coma Scale - 1 to 5"),
		'loc_motor' : fields.integer('Level of Consciousness - Motor', help="Eyes Response - Glasgow Coma Scale - 1 to 6"),		
		'mood' : fields.integer ('Mood',help="1=very angry - 5=very happy"),
		'diagnosis' : fields.many2one ('medical.pathology','Presumptive Diagnosis', help="Presumptive Diagnosis"),
		'info_diagnosis' : fields.text('Presumptive Diagnosis: Extra Info'),
		'directions' : fields.text('Medical Directions'),
		'actions' : fields.many2many('medical.procedure', 'patient_procedures_rel','patient_id','procedure_ids','Procedures'),
		'medications' : fields.many2many('medical.patient.medication', 'patient_medication_rel','patient_id','medication_id','Medications'),
		'notes' : fields.text ('Notes'),
	}

	_defaults = {
                'loc_eyes': lambda *a: 4,
                'loc_verbal': lambda *a: 5,
                'loc_motor': lambda *a: 6,
		'evaluation_type': lambda *a: 'pa',
		'user_id': lambda obj, cr, uid, context: uid
        }


	def onchange_height_weight (self, cr, uid, ids, height, weight):
		if height:
			v = {'bmi':weight/((height/100)**2)}
		else:
			v = {'bmi':0}

		return {'value': v}	
				
	def onchange_loc (self, cr, uid, ids, loc_motor, loc_eyes, loc_verbal):
		v = {'loc':loc_motor + loc_eyes + loc_verbal}
		return {'value': v}	


patient_evaluation ()


class lab (osv.osv):
	_name = "medical.lab"
	_description = "Lab Test"
	_columns = {
		'name' : fields.char ('ID', size=128, help="Lab result ID"),
		'test' : fields.many2one ('medical.test', 'Test type', help="Lab test type"),
		'patient' : fields.many2one ('medical.patient', 'Patient', help="Patient ID"), 
		'pathologist' : fields.many2one ('medical.physician','Pathologist',help="Pathologist"),
		'requestor' : fields.many2one ('medical.physician', 'Physician', help="Doctor who requested the test"),
		'date_requested' : fields.date ('Date requested'),
		'date_analysis' : fields.date ('Date of the Analysis'),
		'results' : fields.text ('Results'),
		'diagnosis' : fields.text ('Diagnosis'),

	}

	_sql_constraints = [
                ('id_uniq', 'unique (name)', 'The test ID code must be unique')]
lab ()

class lab_hemogram (osv.osv):
	_name = "medical.lab.hemogram"
	_description = "Hemogram"
	_columns = {
		'name' : fields.many2one ('medical.lab', 'Test ID', help="Test Identifier. It is a unique ID that correspond with an specific patient test"),
		'rbc' : fields.float ('Red Blood Cells', digits=(16,2), help="Red Blood cell count , (10^12/L)"),
		'hb' : fields.float ('Hemoglobin', digits=(16,2), help="Hemoglobin, in g/L"),
		'hbg' : fields.float ('Glycosylated Hemoglobin', digits=(16,2), help="Glycosylated Hemoglobin , % of Hb"),
		'hct' : fields.float ('Hematocrit', digits=(16,2), help="Hematocrit"),
		'mcv' : fields.float ('Mean Corpuscular Volume', digits=(16,2), help="Mean Corpuscular Volume - MCV, fL"),
		'mch' : fields.float ('Mean Corpuscular Hemoglobin', digits=(16,2), help="Mean Corpuscular Hemoglobin, picograms / Cell "),
		'reticulocytes' : fields.float ('Reticulocytes', digits=(16,2), help="Reticulocytes, % of Red Blood cells"),
		'wbc' : fields.float ('White Blood Cells', digits=(16,2), help="White Blood Cells, x10^9/L"),
		'neutrophils' : fields.float ('Neutrophils', digits=(16,2), help="Neutrophils, x10^9/L"),
		'neutrophils_pct' : fields.float ('% Neutrophils', digits=(16,2), help="Relative value, percentage of the leukocitary formula"),
		'bneutrophils' : fields.float ('Band Neutrophils', digits=(16,2), help="Band Neutrophils, x10^9/L"),
		'bneutrophils_pct' : fields.float ('% Band Neutrophils', digits=(16,2), help="Relative value, percentage of the leukocitary formula"),
		'eosinophils' : fields.float ('Eosinophils', digits=(16,2), help="Eosinophils, x10^9/L"),
		'eosinophils_pct' : fields.float ('% Eosinophils', digits=(16,2), help="Relative value, percentage of the leukocitary formula"),
		'basophils' : fields.float ('Basophils', digits=(16,2), help="Basophils, x10^9/L"),
		'basophils_pct' : fields.float ('% Basophils', digits=(16,2), help="Relative value, percentage of the leukocitary formula"),
		'lymphocytes' : fields.float ('Lymphocytes', digits=(16,2), help="Lymphocytes, x10^9/L"),
		'lymphocytes_pct' : fields.float ('% Lymphocytes', digits=(16,2), help="Relative value, percentage of the leukocitary formula"),
		'monocytes' : fields.float ('Monocytes', digits=(16,2), help="Monocytes, x10^9/L"),
		'monocytes_pct' : fields.float ('% Monocytes', digits=(16,2), help="Relative value, percentage of the leukocitary formula"),
		'platelets' : fields.integer ('Platelets', help="Platelets, x10^9/L"),
		'pt' : fields.float ('Prothrombin Time',digits=(16,2), help="Prothrombin Time in seconds"),
		'inr' : fields.float ('INR', digits=(16,2), help="International Normalized Ratio"),
		'aptt' : fields.float ('APTT', digits=(16,2), help="Activated Partial Tromboplastin Time in seconds"),
		'tct' :  fields.float ('TCT', digits=(16,2), help="Thrombin Clotting Time in seconds"),
		'fibrinogen' : fields.float ('Fibrinogen', digits=(16,2), help="Fibrinogen in g/L"),
		'bt' : 	fields.integer ('Bleeding Time', help="Bleeding time in minutes"),
		}

	def onchange_redcells (self, cr, uid, ids, rbc, hct, hb):
		if rbc:
			v = {'mcv':(hct*10)/rbc , 'mch':(hb*10)/rbc}
		else:
			v = {'mcv':0, 'mch':0}

		return {'value': v}	


	def onchange_whitecells (self, cr, uid, ids, wbc,neutrophils,bneutrophils,eosinophils,basophils,lymphocytes,monocytes):
		if wbc:
			v = {'neutrophils_pct':(neutrophils*100)/wbc , 'bneutrophils_pct':(bneutrophils*100)/wbc, 'eosinophils_pct':(eosinophils*100)/wbc, 'basophils_pct':(basophils*100)/wbc, 'lymphocytes_pct':(lymphocytes*100)/wbc, 'monocytes_pct':(monocytes*100)/wbc}
		else:
			v = {'neutrophils_pct':0, 'bneutrophils_pct':0, 'eosinophils_pct':0, 'basophils_pct':0, 'lymphocytes_pct':0, 'monocytes_pct':0}

		return {'value': v}	


	def onchange_whitecells_pct (self, cr, uid, ids, wbc,neutrophils_pct,bneutrophils_pct,eosinophils_pct,basophils_pct,lymphocytes_pct,monocytes_pct):
		if wbc:
			v = {'neutrophils':(neutrophils_pct*wbc)/100 , 'bneutrophils':(bneutrophils_pct*wbc)/100, 'eosinophils':(eosinophils_pct*wbc)/100, 'basophils':(basophils_pct*wbc)/100, 'lymphocytes':(lymphocytes_pct*wbc)/100, 'monocytes':(monocytes_pct*wbc)/100}
		else:
			v = {'neutrophils':0, 'bneutrophils':0, 'eosinophils':0, 'basophils':0, 'lymphocytes':0, 'monocytes':0}

		return {'value': v}	


lab_hemogram ()

class lab_hepatogram (osv.osv):
	_name = "medical.lab.hepatogram"
	_description = "Hepatogram"
	_columns = {
		'name' : fields.many2one ('medical.lab', 'Test ID', help="Test Identifier. It is a unique ID that correspond with an specific patient test"),
		'alp' : fields.float ('Alkaline phosphatase', digits=(16,2), help="Alkaline phosphatase - ALP, (IU/L)"),
		'alt' : fields.float ('Alanine Transferase', digits=(16,2), help="Alanine Transferase / GPT, (IU/L)"),
		'ast' : fields.float ('Aspartate Transferase', digits=(16,2), help="Alanine Transferase / GOT, (IU/L)"),
		'bilirubin' : fields.float ('Bilirubin', digits=(16,2), help="Bilirubin, (mg/dl)"),
		'bilirubin_bc' : fields.float ('Direct Bilirubin', digits=(16,2), help="Direct / Conjugated Bilirubin, (mg/dl)"),
		'triglycerides' : fields.float ('Triglycerides', digits=(16,2), help="Triglycerides, (mg/dl)"),
		'cholesterol' : fields.float ('Cholesterol', digits=(16,2), help="Cholesterol (Total), (mg/dl)"),
		'hdl' : fields.float ('HDL', digits=(16,2), help="HDL - High Density Lipoprotein, (mg/dl)"),
		'ldl' : fields.float ('LDL', digits=(16,2), help="LDL - Low Density Lipoprotein, (mg/dl)"),
		}

lab_hepatogram ()

